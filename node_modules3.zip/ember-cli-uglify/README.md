# Ember-CLI-uglify

This addon adds a minification step to the Ember-CLI build process
