import pluralize from 'ember-inflector/lib/helpers/pluralize';
export default pluralize;
