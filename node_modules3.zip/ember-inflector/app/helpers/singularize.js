import singularize from 'ember-inflector/lib/helpers/singularize';
export default singularize;
