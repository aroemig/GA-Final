import FirebaseProvider from 'emberfire/torii-providers/firebase';

export default FirebaseProvider;
