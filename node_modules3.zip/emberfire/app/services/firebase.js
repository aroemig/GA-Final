import firebase from 'emberfire/services/firebase';

export default firebase;
