import firebaseApp from 'emberfire/services/firebase-app';

export default firebaseApp;
