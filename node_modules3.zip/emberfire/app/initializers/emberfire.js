import EmberFireInitializer from 'emberfire/initializers/emberfire';

export default EmberFireInitializer;
