The Ember team and community are committed to everyone having a safe and inclusive experience.

**Our Community Guidelines / Code of Conduct can be found here**:

http://emberjs.com/guidelines/

For a history of updates, see the page history here:

https://github.com/emberjs/website/commits/master/source/guidelines.html.erb
