/*jshint node:true*/

module.exports = {
  description: 'Generates an ember-data value transform.'
};
