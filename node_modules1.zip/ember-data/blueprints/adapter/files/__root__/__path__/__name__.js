<%= importStatement %>

export default <%= baseClass %>.extend({
});
