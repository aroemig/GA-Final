/*!
 * @overview  Ember Data
 * @copyright Copyright 2011-2016 Tilde Inc. and contributors.
 *            Portions Copyright 2011 LivingSocial Inc.
 * @license   Licensed under MIT license (see license.js)
 * @version   VERSION_STRING_PLACEHOLDER
 */
