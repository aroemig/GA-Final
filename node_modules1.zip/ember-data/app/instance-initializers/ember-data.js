import initializeStoreService from 'ember-data/-private/instance-initializers/initialize-store-service';

export default {
  name: "ember-data",
  initialize: initializeStoreService
};
