import Model from "ember-data/-private/system/model";

export default Model;
