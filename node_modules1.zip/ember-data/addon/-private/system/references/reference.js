var Reference = function(store, internalModel) {
  this.store = store;
  this.internalModel = internalModel;
};

Reference.prototype = {
  constructor: Reference
};

export default Reference;
