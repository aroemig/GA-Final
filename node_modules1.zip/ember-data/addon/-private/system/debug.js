/**
  @module ember-data
*/

import DebugAdapter from "ember-data/-private/system/debug/debug-adapter";

export default DebugAdapter;
