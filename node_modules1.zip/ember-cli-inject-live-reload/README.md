#ember-cli-inject-live-reload

Plugin for ember-cli that injects live-reload script into HTML content.
