# ember-cli-get-component-path-option
