'use strict';
var getCallerFile = require('../');

module.exports = function() {
  return getCallerFile();
};
