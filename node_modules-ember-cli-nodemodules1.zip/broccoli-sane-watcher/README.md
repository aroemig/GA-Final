broccoli-sane-watcher
=====================

[![Build Status](https://travis-ci.org/krisselden/broccoli-sane-watcher.svg)](https://travis-ci.org/krisselden/broccoli-sane-watcher)

A drop in replacement for Broccoli's Watcher that uses the sane module for file watching.
