'use strict';

module.exports = {
  trackError: function() {
  }
};
