# master

* Do not use `CoreObject`
* Derive from broccoli-plugin base class

# 0.2.3

* Make `new` operator optional
* Use [new `.rebuild` API](https://github.com/broccolijs/broccoli/blob/master/docs/new-rebuild-api.md)
* Avoid mutating array arguments

# 0.2.2

No changelog beyond this point. Here be dragons.
