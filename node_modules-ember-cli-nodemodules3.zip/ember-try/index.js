/* jshint node: true */
'use strict';

module.exports = {
  name: 'ember-try',
  includedCommands: function() {
    return require('./lib/commands');
  }
};
