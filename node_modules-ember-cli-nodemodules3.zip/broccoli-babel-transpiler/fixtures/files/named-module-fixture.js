const foo = 5;
const bar = 6;

export { foo, bar };