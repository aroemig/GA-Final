"use strict";

var x = 0;