define("foo", ["exports"], function (exports) {
  "use strict";

  var foo = 5;
  var bar = 6;

  exports.foo = foo;
  exports.bar = bar;
});