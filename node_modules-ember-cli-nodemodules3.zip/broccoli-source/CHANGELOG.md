# master

# 1.1.0

* Allow for calling `__broccoliGetInfo__` without argument
* Add missing `__broccoliFeatures__` object

# 1.0.0

* Initial release
