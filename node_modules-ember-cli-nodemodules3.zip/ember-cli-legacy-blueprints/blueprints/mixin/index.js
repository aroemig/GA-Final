module.exports = {
  description: 'Generates a mixin.'
};
