module.exports = {
  description: 'Generates a controller.'
};
