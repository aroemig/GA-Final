module.exports = {
  description: 'Generates a template.'
};
