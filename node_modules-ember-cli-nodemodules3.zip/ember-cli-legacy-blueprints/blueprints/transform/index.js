module.exports = {
  description: 'Generates an ember-data value transform.'
};
