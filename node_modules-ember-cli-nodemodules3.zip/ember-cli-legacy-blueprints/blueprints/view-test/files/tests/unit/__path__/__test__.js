import { moduleFor, test } from 'ember-qunit';

moduleFor('view:<%= dasherizedModuleName %>', '<%= friendlyTestDescription %>');

// Replace this with your real tests.
test('it exists', function(assert) {
  var view = this.subject();
  assert.ok(view);
});
