export default function <%= camelizedModuleName %>() {
  return true;
}
