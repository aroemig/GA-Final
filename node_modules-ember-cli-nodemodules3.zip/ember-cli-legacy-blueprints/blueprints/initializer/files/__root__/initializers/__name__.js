export function initialize(/* application */) {
  // application.inject('route', 'foo', 'service:foo');
}

export default {
  name: '<%= dasherizedModuleName %>',
  initialize
};
