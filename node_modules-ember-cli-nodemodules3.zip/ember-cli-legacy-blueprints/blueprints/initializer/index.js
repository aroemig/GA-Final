module.exports = {
  description: 'Generates an initializer.'
};
