module.exports = {
  description: 'Generates a test helper.'
};
