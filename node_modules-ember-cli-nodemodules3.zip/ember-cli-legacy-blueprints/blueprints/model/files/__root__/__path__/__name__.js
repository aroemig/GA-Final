<%= importStatements %>

export default Model.extend({
  <%= attrs %>
});
