module.exports = {
  description: 'Generates an instance initializer.'
};
