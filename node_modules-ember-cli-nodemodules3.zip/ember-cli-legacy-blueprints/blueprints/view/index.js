module.exports = {
  description: 'Generates a view subclass.'
};
