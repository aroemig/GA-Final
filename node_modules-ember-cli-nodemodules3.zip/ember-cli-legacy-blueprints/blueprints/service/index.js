module.exports = {
  description: 'Generates a service.'
};
