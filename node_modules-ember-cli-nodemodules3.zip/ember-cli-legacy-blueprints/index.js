'use strict';

module.exports = {
  name: 'ember-cli-legacy-blueprints'
};
