module.exports = {
  rules: {
    // JSHint "strict"
    'strict': 0,
  },
};
