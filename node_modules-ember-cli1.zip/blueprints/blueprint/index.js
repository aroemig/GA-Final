/*jshint node:true*/

module.exports = {
  description: 'Generates a blueprint and definition.'
};
