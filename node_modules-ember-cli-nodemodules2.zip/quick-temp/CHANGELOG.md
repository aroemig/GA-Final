# master

# 0.1.5

* Always ensure the `./tmp` dir exists

# 0.1.4

* `makeOrRemake` now reuses its temporary directory, keeping the path the same

# 0.1.3

* Add optional `className` parameter

# 0.1.2

* Use absolute path for temp directory.

# 0.1.1

* Do not put "object" into directory name

# 0.1.0

* Bump version without change, to allow for caret/tilde dependencies

# 0.0.2

* Do not fail if `remove` is called on undefined property
* Use pretty names for temporary directories

# 0.0.1

* Initial release
