var meaningOfLife = 42;
//# sourceMappingURL=sneaky.map