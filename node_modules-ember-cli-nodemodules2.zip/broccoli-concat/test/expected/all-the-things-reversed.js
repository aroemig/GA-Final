/* This is my header.s*/
function somethingElse() {
  throw new Error("somethign else");
}

function meaningOfLife() {
  throw new Error(42);
}

function boom() {
  throw new Error('boom');
}


// Hello world

function fourth(){
  throw new Error('fourth');
}

function third(){
  throw new Error("oh no");
}

/* This is my footer. */
//# sourceMappingURL=all-the-things-reversed.map