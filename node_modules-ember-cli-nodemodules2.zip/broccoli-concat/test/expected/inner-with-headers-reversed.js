
// Hello world

function fourth(){
  throw new Error('fourth');
}

function third(){
  throw new Error("oh no");
}

function meaningOfLife() {
  throw new Error(42);
}

function boom() {
  throw new Error('boom');
}

function somethingElse() {
  throw new Error("somethign else");
}
//# sourceMappingURL=inner-with-headers-reversed.map