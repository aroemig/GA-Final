var meaningOfLife = 42;
