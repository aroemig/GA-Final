
// Hello world

function fourth(){
  throw new Error('fourth');
}
