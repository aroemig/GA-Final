function meaningOfLife() {
  throw new Error(42);
}

function boom() {
  throw new Error('boom');
}
