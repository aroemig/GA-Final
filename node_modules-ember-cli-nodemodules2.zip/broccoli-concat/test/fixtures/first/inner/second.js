function somethingElse() {
  throw new Error("somethign else");
}
