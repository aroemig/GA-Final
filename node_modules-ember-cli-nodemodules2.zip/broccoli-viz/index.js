'use strict';

module.exports = {
  dot: require('./dot'),
  flatten: require('./flatten'),
  process: require('./process')
};
