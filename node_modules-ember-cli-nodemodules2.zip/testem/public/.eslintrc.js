'use strict';

module.exports = {
  env: {
    browser: true,
    node: false
  }
}
