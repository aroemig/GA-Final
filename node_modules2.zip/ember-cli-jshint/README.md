
ember-cli-jshint
==============================================================================

[JSHint](http://jshint.com/) lint tests for your Ember CLI projects.


Installation
------------------------------------------------------------------------------

From within your Ember CLI application run:

```bash
ember install ember-cli-jshint
```


License
------------------------------------------------------------------------------

This project is licensed under the [MIT License](LICENSE).
