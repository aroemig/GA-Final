export { default } from './resolver';
