/* jshint node: true */
'use strict';

module.exports = {
  name: 'ember-getowner-polyfill'
};
