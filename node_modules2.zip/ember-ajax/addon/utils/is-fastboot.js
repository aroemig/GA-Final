/* global FastBoot */
const isFastBoot = typeof FastBoot !== 'undefined';
export default isFastBoot;
