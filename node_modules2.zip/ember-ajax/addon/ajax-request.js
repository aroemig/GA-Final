import Ember from 'ember';
import AjaxRequestMixin from './mixins/ajax-request';

export default Ember.Object.extend(AjaxRequestMixin);
