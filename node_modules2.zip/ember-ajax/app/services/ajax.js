export { default } from 'ember-ajax/services/ajax';
