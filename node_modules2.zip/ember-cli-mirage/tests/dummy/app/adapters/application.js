import ActiveModelAdapter from 'active-model-adapter';

export default ActiveModelAdapter;
