export default [
  {
    id: 1,
    name: 'Link',
  },
];
