export default [
  {
    id: 1,
    title: 'Lorem',
    wordSmithId: 1
  },
  {
    id: 2,
    title: 'Ipsum',
    wordSmithId: 1
  },
  {
    id: 3,
    title: 'Dolor',
    wordSmithId: 1
  }
];
