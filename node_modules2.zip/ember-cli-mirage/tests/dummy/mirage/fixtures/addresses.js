export default [
  {
    id: 1,
    name: '123 Hyrule Way',
    contact_id: 1
  },
  {
    id: 2,
    name: 'Mount Doom',
    contact_id: 2
  },
];
