export default [
  {
    id: 1,
    name: 'Joe',
    address_ids: [1]
  },
  {
    id: 2,
    name: 'Bob'
  },
  {
    id: 3,
    name: 'Susan'
  },
];
