export default [
  {
    id: 1,
    name: 'Joe',
    age: 10,
    isYoung: true
  },
  {
    id: 2,
    name: 'Bob',
    age: 80,
    isYoung: false
  }
];
