import ActiveModelSerializer from 'ember-cli-mirage/serializers/active-model-serializer';

export default ActiveModelSerializer;
