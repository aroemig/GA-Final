# 2.1.0
- bump broccoli-sri-hash to 2.1.0
- Add fingerprintCheck option and documentation
- lock jQuery to 1.11.3 to [fix Travis and AppVery issues](http://emberjs.com/blog/2016/01/15/ember-2-3-released.html#toc_removing-the-jquery-version-assertion)

# 2.0.0
- Disable paranoiaCheck by default

# 1.1.0
- Enable by default paranoiaCheck
- Force code to run after ember-cli-gzip thanks @taylon

# 1.0.4
- Removal of ember-data from package.json as not required and failing tests
- Fixing acceptance test injection
- Updating to latest ember-cli-build syntax

# 1.0.1
# 1.0.2
# 1.0.3

- README fixes

# 1.0.0
- Bumped to the latest version of broccoli-sri-hash
- Updated README to add in lots of help and rationale of use

# 0.2.4
- Bumped to the latest version of broccoli-sri-hash to fix link only to apply on stylesheets

# 0.2.3
- Bumped to the latest version of broccoli-sri-hash

# 0.2.2
- Added in ability to specify `origin` to match against `SRI.fingerprint` to simplify interface
- Improved README
